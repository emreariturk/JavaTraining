package com.in28minutes.rest.webservices.resfullwebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResfullWebServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResfullWebServicesApplication.class, args);
	}

}
